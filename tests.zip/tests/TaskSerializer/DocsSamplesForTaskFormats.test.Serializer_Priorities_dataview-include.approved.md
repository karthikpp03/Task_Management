<!-- placeholder to force blank line before included text -->

- [ ] #task Lowest priority  [priority:: lowest]
- [ ] #task Low priority  [priority:: low]
- [ ] #task Normal priority
- [ ] #task Medium priority  [priority:: medium]
- [ ] #task High priority  [priority:: high]
- [ ] #task Highest priority  [priority:: highest]

<!-- placeholder to force blank line after included text -->
