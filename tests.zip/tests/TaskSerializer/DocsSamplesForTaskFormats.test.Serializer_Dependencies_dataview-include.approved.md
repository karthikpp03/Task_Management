<!-- placeholder to force blank line before included text -->

- [ ] do this first  [id:: dcf64c]
- [ ] do this after first and some other task  [dependsOn:: dcf64c,0h17ye]

<!-- placeholder to force blank line after included text -->
