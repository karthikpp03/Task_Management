<!-- placeholder to force blank line before included text -->


```javascript
group by function task.urgency.toFixed(3)
```

- Show the urgency to 3 decimal places, unlike the built-in "group by urgency" which uses 2.


<!-- placeholder to force blank line after included text -->
