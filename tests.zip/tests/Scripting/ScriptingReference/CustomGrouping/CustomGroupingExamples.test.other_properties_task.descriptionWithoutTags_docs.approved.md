<!-- placeholder to force blank line before included text -->


```javascript
group by function task.descriptionWithoutTags
```

- Like `group by description`, but it removes any tags from the group headings.
- This might be useful for finding completed recurrences of the same task, even if the tags differ in some recurrences.


<!-- placeholder to force blank line after included text -->
