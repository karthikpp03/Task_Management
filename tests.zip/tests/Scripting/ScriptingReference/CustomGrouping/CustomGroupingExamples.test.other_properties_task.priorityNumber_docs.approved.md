<!-- placeholder to force blank line before included text -->


```javascript
group by function task.priorityNumber
```

- Group by the task's priority number, where Highest is 0 and Lowest is 5.


<!-- placeholder to force blank line after included text -->
