<!-- placeholder to force blank line before included text -->


```javascript
group by function task.isRecurring ? "Recurring" : "Non-Recurring"
```

- Use JavaScript's ternary operator to choose what to do for true (after the ?) and false (after the :) values.


<!-- placeholder to force blank line after included text -->
