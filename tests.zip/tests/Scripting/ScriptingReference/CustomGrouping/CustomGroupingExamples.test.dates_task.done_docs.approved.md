<!-- placeholder to force blank line before included text -->


```javascript
group by function task.done.format("YYYY-MM-DD dddd")
```

- Like "group by done", except it uses an empty string instead of "No done date" if there is no done date.


<!-- placeholder to force blank line after included text -->
