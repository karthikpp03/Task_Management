<!-- placeholder to force blank line before included text -->


```javascript
group by function task.scheduled.format("YYYY-MM-DD dddd")
```

- Like "group by scheduled", except it uses an empty string instead of "No scheduled date" if there is no scheduled date.


<!-- placeholder to force blank line after included text -->
