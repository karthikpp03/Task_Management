<!-- placeholder to force blank line before included text -->


```javascript
group by function "Status symbol: " + task.status.symbol.replace(" ", "space")
```

- Group by the status symbol, making space characters visible.


<!-- placeholder to force blank line after included text -->
