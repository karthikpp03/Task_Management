<!-- placeholder to force blank line before included text -->


```javascript
group by function task.start.format("YYYY-MM-DD dddd")
```

- Like "group by start", except it uses an empty string instead of "No start date" if there is no start date.


<!-- placeholder to force blank line after included text -->
