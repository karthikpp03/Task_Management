<!-- placeholder to force blank line before included text -->


```javascript
group by function task.status.type
```

- Unlike "group by status.type", this sorts the status types in alphabetical order.

```javascript
group by function task.status.typeGroupText
```

- This sorts the status types in the same order as "group by status.type".


<!-- placeholder to force blank line after included text -->
