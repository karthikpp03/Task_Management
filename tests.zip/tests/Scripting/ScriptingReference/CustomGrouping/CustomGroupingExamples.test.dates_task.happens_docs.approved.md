<!-- placeholder to force blank line before included text -->


```javascript
group by function task.happens.format("YYYY-MM-DD dddd")
```

- Like "group by happens", except it uses an empty string instead of "No happens date" if there is no happens date.


<!-- placeholder to force blank line after included text -->
