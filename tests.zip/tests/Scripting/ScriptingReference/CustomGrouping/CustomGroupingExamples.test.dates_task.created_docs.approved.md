<!-- placeholder to force blank line before included text -->


```javascript
group by function task.created.format("YYYY-MM-DD dddd")
```

- Like "group by created", except it uses an empty string instead of "No created date" if there is no created date.


<!-- placeholder to force blank line after included text -->
