<!-- placeholder to force blank line before included text -->


```javascript
group by function "Next status symbol: " + task.status.nextSymbol.replace(" ", "space")
```

- Group by the next status symbol, making space characters visible.


<!-- placeholder to force blank line after included text -->
