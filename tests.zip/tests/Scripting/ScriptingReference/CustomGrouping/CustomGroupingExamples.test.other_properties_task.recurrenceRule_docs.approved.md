<!-- placeholder to force blank line before included text -->


```javascript
group by function task.recurrenceRule.replace('when done', '==when done==')
```

- Group by recurrence rule, highlighting any occurrences of the words "when done".


<!-- placeholder to force blank line after included text -->
