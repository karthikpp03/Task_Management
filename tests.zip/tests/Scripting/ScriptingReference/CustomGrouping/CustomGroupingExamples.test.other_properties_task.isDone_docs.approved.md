<!-- placeholder to force blank line before included text -->


```javascript
group by function task.isDone ? "Action Required" : "Nothing To Do"
```

- Use JavaScript's ternary operator to choose what to do for true (after the ?) and false (after the :) values.


<!-- placeholder to force blank line after included text -->
