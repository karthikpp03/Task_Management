<!-- placeholder to force blank line before included text -->


```javascript
group by function task.cancelled.format("YYYY-MM-DD dddd")
```

- Like "group by cancelled", except it uses an empty string instead of "No cancelled date" if there is no cancelled date.


<!-- placeholder to force blank line after included text -->
