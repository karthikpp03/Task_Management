<!-- placeholder to force blank line before included text -->


```javascript
group by function task.dependsOn
```

- Group by the Ids of the tasks that each task depends on, if any.
- If a task depends on more than one other task, it will be listed multiple times.
- Note that currently there is no way to access the tasks being depended on.


<!-- placeholder to force blank line after included text -->
