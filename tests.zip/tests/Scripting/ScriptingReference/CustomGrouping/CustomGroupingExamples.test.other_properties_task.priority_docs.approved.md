<!-- placeholder to force blank line before included text -->

- ``group by function task.priority``
    - Group by the task's priority number, where Highest is 0 and Lowest is 5.


<!-- placeholder to force blank line after included text -->
