<!-- placeholder to force blank line before included text -->


```javascript
group by function task.file.root
```

- Same as 'group by root'.


<!-- placeholder to force blank line after included text -->
