<!-- placeholder to force blank line before included text -->


```javascript
group by function task.status.name
```

- Identical to "group by status.name".

```javascript
group by function task.status.name.toUpperCase()
```

- Convert the status names to capitals.


<!-- placeholder to force blank line after included text -->
