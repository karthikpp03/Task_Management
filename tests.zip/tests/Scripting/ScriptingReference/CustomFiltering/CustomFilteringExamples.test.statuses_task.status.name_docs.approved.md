<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.status.name === 'Unknown'
```

- Find all tasks with custom statuses not yet added to the Tasks settings.


<!-- placeholder to force blank line after included text -->
