<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.scheduled.format('dddd') === 'Wednesday'
```

- Find tasks scheduled on Wednesdays, that is, any Wednesday.
- On non-English systems, you may need to supply the day of the week in the local language.


<!-- placeholder to force blank line after included text -->
