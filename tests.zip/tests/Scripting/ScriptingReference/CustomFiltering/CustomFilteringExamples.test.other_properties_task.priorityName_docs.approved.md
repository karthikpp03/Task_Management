<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.priorityName !== 'Normal'
```

- The same as `priority is not none`.


<!-- placeholder to force blank line after included text -->
