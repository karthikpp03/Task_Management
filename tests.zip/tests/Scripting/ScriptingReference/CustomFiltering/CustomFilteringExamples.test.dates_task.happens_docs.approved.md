<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.happens.format('dddd') === 'Friday'
```

- Find tasks happens on Fridays, that is, any Friday.
- On non-English systems, you may need to supply the day of the week in the local language.


<!-- placeholder to force blank line after included text -->
