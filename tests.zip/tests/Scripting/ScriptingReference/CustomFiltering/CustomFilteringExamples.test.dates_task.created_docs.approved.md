<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.created.format('dddd') === 'Monday'
```

- Find tasks created on Mondays, that is, any Monday.
- On non-English systems, you may need to supply the day of the week in the local language.


<!-- placeholder to force blank line after included text -->
