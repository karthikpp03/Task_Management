<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.done.format('dddd') === 'Thursday'
```

- Find tasks done on Thursdays, that is, any Thursday.
- On non-English systems, you may need to supply the day of the week in the local language.


<!-- placeholder to force blank line after included text -->
