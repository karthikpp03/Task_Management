<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.due.format('dddd') === 'Tuesday'
```

- Find tasks due on Tuesdays, that is, any Tuesday.
- On non-English systems, you may need to supply the day of the week in the local language.


<!-- placeholder to force blank line after included text -->
