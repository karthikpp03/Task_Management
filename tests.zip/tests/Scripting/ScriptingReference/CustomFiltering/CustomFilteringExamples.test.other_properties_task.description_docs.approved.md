<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.description.length > 100
```

- Find tasks with long descriptions.


<!-- placeholder to force blank line after included text -->
