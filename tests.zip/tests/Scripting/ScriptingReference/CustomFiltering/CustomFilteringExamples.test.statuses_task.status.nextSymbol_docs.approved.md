<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.status.symbol === task.status.nextSymbol
```

- Find tasks that toggle to themselves, because the next symbol is the same as the current symbol.


<!-- placeholder to force blank line after included text -->
