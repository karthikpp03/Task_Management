<!-- placeholder to force blank line before included text -->


```javascript
filter by function task.start.format('dddd') === 'Sunday'
```

- Find tasks starting on Sundays, that is, any Sunday.
- On non-English systems, you may need to supply the day of the week in the local language.


<!-- placeholder to force blank line after included text -->
