<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.done.format("dddd")
```

- Sort by done date's day of the week, alphabetically.


<!-- placeholder to force blank line after included text -->
