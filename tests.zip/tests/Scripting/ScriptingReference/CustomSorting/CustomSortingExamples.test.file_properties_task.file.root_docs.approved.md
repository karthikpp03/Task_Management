<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.file.root
```

- Enable sorting by the root folder.


<!-- placeholder to force blank line after included text -->
