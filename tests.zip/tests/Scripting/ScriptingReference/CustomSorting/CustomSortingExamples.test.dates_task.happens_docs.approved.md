<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.happens.format("dddd")
```

- Sort by happens date's day of the week, alphabetically.


<!-- placeholder to force blank line after included text -->
