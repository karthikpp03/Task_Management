<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.descriptionWithoutTags
```

- Like `Sort by description`, but it removes any tags from the sort key.
- This might be useful for sorting together completed recurrences of the same task, even if the tags differ in some recurrences.


<!-- placeholder to force blank line after included text -->
