<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.blockLink
```

- DO NOT RELEASE UNTIL THE LEADING SPACE IS REMOVED FROM BLOCKLINKS. Removing the leading space and carat prevents the rendered heading itself being treated as a blocklink.


<!-- placeholder to force blank line after included text -->
