<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.priorityName
```

- Sort by the task's priority name.
- The priority names are displayed in alphabetical order.
- Note that the default priority is called 'Normal', as opposed to with `Sort by priority` which calls the default 'None'.


<!-- placeholder to force blank line after included text -->
