<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.status.type
```

- Unlike "Sort by status.type", this sorts the status types in alphabetical order.


<!-- placeholder to force blank line after included text -->
