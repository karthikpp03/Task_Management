<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.isRecurring
```

- Sort by whether the task is recurring: recurring tasks will be listed before non-recurring ones.


<!-- placeholder to force blank line after included text -->
