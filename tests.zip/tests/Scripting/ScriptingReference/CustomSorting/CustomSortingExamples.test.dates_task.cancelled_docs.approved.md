<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.cancelled.format("dddd")
```

- Sort by cancelled date's day of the week, alphabetically.


<!-- placeholder to force blank line after included text -->
