<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.scheduled.format("dddd")
```

- Sort by scheduled date's day of the week, alphabetically.


<!-- placeholder to force blank line after included text -->
