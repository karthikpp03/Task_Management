<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.heading
```

- Like 'sort by heading'.
- Any tasks with no preceding heading have `task.heading` values of `null`, and these tasks sort before any tasks with headings.


<!-- placeholder to force blank line after included text -->
