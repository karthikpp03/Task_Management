<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.due.format("dddd")
```

- Sort by due date's day of the week, alphabetically.


<!-- placeholder to force blank line after included text -->
