<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.file.path
```

- Like 'Sort by path' but includes the file extension.

```javascript
sort by function task.file.pathWithoutExtension
```

- Like 'Sort by path'.


<!-- placeholder to force blank line after included text -->
