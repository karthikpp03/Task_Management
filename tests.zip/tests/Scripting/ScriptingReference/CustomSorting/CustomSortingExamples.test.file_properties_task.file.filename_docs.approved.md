<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.file.filename
```

- Like 'sort by filename' but includes the file extension.

```javascript
sort by function task.file.filenameWithoutExtension
```

- Like 'sort by filename'.


<!-- placeholder to force blank line after included text -->
