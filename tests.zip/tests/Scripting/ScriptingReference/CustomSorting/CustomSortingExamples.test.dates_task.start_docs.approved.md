<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.start.format("dddd")
```

- Sort by start date's day of the week, alphabetically.


<!-- placeholder to force blank line after included text -->
