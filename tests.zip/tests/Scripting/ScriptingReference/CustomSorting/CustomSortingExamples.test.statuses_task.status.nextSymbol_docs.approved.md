<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.status.nextSymbol
```

- Sort by the next status symbol.


<!-- placeholder to force blank line after included text -->
