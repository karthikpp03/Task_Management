<!-- placeholder to force blank line before included text -->


```javascript
sort by function reverse task.urgency
```

- Sort by task urgency values.
- We use `reverse` to put the most urgent tasks first.


<!-- placeholder to force blank line after included text -->
