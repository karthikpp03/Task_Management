<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.status.name
```

- Identical to "Sort by status.name".


<!-- placeholder to force blank line after included text -->
