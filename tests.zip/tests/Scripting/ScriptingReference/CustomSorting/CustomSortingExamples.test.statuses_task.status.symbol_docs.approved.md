<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.status.symbol
```

- Sort by the status symbol.


<!-- placeholder to force blank line after included text -->
