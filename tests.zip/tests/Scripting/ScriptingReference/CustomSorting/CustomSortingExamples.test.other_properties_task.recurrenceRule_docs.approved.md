<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.recurrenceRule
```

- Sort by recurrence rule.


<!-- placeholder to force blank line after included text -->
