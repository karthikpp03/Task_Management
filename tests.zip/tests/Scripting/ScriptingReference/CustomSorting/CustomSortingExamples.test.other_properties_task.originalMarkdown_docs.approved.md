<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.originalMarkdown
```

- Sort by the raw text of the task's original line in the MarkDown file.


<!-- placeholder to force blank line after included text -->
