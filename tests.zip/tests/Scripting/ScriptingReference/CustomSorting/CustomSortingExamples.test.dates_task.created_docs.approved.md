<!-- placeholder to force blank line before included text -->


```javascript
sort by function task.created.format("dddd")
```

- Sort by created date's day of the week, alphabetically.


<!-- placeholder to force blank line after included text -->
