<!-- placeholder to force blank line before included text -->

~~~text
return 42
=> 42

const x = 1 + 1; return x * x
=> 4

if (1 === 1) { return "yes"; } else { return "no" }
=> 'yes'

function f(value) {                 \
    if (value === 1 ) {             \
        return "yes";               \
    } else {                        \
        return "no";                \
    }                               \
}                                   \
return f(1);
=> 'yes'
~~~


<!-- placeholder to force blank line after included text -->
