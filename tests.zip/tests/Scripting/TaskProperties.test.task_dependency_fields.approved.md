<!-- placeholder to force blank line before included text -->

| Field | Type 1 | Example 1 | Type 2 | Example 2 |
| ----- | ----- | ----- | ----- | ----- |
| `task.id` | `string` | `'abcdef'` | `string` | `''` |
| `task.dependsOn` | `string[]` | `['123456', 'abc123']` | `any[]` | `[]` |
| `task.isBlocked(query.allTasks)` | `boolean` | `false` | `boolean` | `false` |
| `task.isBlocking(query.allTasks)` | `boolean` | `false` | `boolean` | `false` |


<!-- placeholder to force blank line after included text -->
