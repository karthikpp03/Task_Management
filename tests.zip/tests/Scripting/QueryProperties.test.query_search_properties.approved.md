<!-- placeholder to force blank line before included text -->

| Field | Type | Example |
| ----- | ----- | ----- |
| `query.allTasks` | `Task[]` | `[... an array with all the Tasks-tracked tasks in the vault ...]` |


<!-- placeholder to force blank line after included text -->
