<!-- placeholder to force blank line before included text -->

- [ ] #task `space` Unchecked
- [x] #task `x` Checked
- [>] #task `>` Rescheduled
- [<] #task `<` Scheduled
- [!] #task `!` Important
- [-] #task `-` Cancelled
- [/] #task `/` In Progress
- [?] #task `?` Question
- [*] #task `*` Star
- [n] #task `n` Note
- [l] #task `l` Location
- [i] #task `i` Information
- [I] #task `I` Idea
- [S] #task `S` Amount
- [p] #task `p` Pro
- [c] #task `c` Con
- [b] #task `b` Bookmark
- ["] #task `"` Quote
- [0] #task `0` Speech bubble 0
- [1] #task `1` Speech bubble 1
- [2] #task `2` Speech bubble 2
- [3] #task `3` Speech bubble 3
- [4] #task `4` Speech bubble 4
- [5] #task `5` Speech bubble 5
- [6] #task `6` Speech bubble 6
- [7] #task `7` Speech bubble 7
- [8] #task `8` Speech bubble 8
- [9] #task `9` Speech bubble 9


<!-- placeholder to force blank line after included text -->
