<!-- placeholder to force blank line before included text -->

| Status Symbol | Next Status Symbol | Status Name<br>`status.name includes...`<br>`sort by status.name`<br>`group by status.name` | Status Type<br>`status.type is...`<br>`sort by status.type`<br>`group by status.type` | Needs Custom Styling |
| ----- | ----- | ----- | ----- | ----- |
| `space` | `x` | incomplete | `TODO` | No |
| `x` | `space` | complete / done | `DONE` | No |
| `-` | `space` | cancelled | `CANCELLED` | Yes |
| `>` | `x` | deferred | `TODO` | Yes |
| `/` | `x` | in progress, or half-done | `IN_PROGRESS` | Yes |
| `!` | `x` | Important | `TODO` | Yes |
| `?` | `x` | question | `TODO` | Yes |
| `R` | `x` | review | `TODO` | Yes |
| `+` | `x` | Inbox / task that should be processed later | `TODO` | Yes |
| `b` | `x` | bookmark | `TODO` | Yes |
| `B` | `x` | brainstorm | `TODO` | Yes |
| `D` | `x` | deferred or scheduled | `TODO` | Yes |
| `I` | `x` | Info | `TODO` | Yes |
| `i` | `x` | idea | `TODO` | Yes |
| `N` | `x` | note | `TODO` | Yes |
| `Q` | `x` | quote | `TODO` | Yes |
| `W` | `x` | win / success / reward | `TODO` | Yes |
| `P` | `x` | pro | `TODO` | Yes |
| `C` | `x` | con | `TODO` | Yes |


<!-- placeholder to force blank line after included text -->
