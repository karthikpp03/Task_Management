<!-- placeholder to force blank line before included text -->

- [ ] #task `space` Unchecked
- [x] #task `x` Checked
- [-] #task `-` Cancelled
- [/] #task `/` In Progress
- [>] #task `>` Deferred
- [!] #task `!` Important
- [?] #task `?` Question
- [r] #task `r` Review


<!-- placeholder to force blank line after included text -->
