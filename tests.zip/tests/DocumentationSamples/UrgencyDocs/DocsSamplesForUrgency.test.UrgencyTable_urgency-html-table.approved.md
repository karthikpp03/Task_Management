<!-- placeholder to force blank line before included text -->


<table>
<thead>
  <tr>
    <th colspan="2">Property</th>
    <th>Score</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td rowspan="25">Due</td>
    <td>due more than 7 days ago</td>
    <td><code>12.00000</code></td>
  </tr>
  <tr>
    <td>due 7 days ago</td>
    <td><code>12.00000</code></td>
  </tr>
  <tr>
    <td>due 6 days ago</td>
    <td><code>11.54286</code></td>
  </tr>
  <tr>
    <td>due 5 days ago</td>
    <td><code>11.08571</code></td>
  </tr>
  <tr>
    <td>due 4 days ago</td>
    <td><code>10.62857</code></td>
  </tr>
  <tr>
    <td>due 3 days ago</td>
    <td><code>10.17143</code></td>
  </tr>
  <tr>
    <td>due 2 days ago</td>
    <td><code>9.71429</code></td>
  </tr>
  <tr>
    <td>due 1 day ago</td>
    <td><code>9.25714</code></td>
  </tr>
  <tr>
    <td>Today</td>
    <td><code>8.80000</code></td>
  </tr>
  <tr>
    <td>1 day until due</td>
    <td><code>8.34286</code></td>
  </tr>
  <tr>
    <td>2 days until due</td>
    <td><code>7.88571</code></td>
  </tr>
  <tr>
    <td>3 days until due</td>
    <td><code>7.42857</code></td>
  </tr>
  <tr>
    <td>4 days until due</td>
    <td><code>6.97143</code></td>
  </tr>
  <tr>
    <td>5 days until due</td>
    <td><code>6.51429</code></td>
  </tr>
  <tr>
    <td>6 days until due</td>
    <td><code>6.05714</code></td>
  </tr>
  <tr>
    <td>7 days until due</td>
    <td><code>5.60000</code></td>
  </tr>
  <tr>
    <td>8 days until due</td>
    <td><code>5.14286</code></td>
  </tr>
  <tr>
    <td>9 days until due</td>
    <td><code>4.68571</code></td>
  </tr>
  <tr>
    <td>10 days until due</td>
    <td><code>4.22857</code></td>
  </tr>
  <tr>
    <td>11 days until due</td>
    <td><code>3.77143</code></td>
  </tr>
  <tr>
    <td>12 days until due</td>
    <td><code>3.31429</code></td>
  </tr>
  <tr>
    <td>13 days until due</td>
    <td><code>2.85714</code></td>
  </tr>
  <tr>
    <td>14 days until due</td>
    <td><code>2.40000</code></td>
  </tr>
  <tr>
    <td>More than 14 days until due</td>
    <td><code>2.40000</code></td>
  </tr>
  <tr>
    <td>None</td>
    <td><code>0.00000</code></td>
  </tr>
  <tr>
    <td rowspan="6">Priority</td>
    <td>Highest</td>
    <td><code>9.0</code></td>
  </tr>
  <tr>
    <td>High</td>
    <td><code>6.0</code></td>
  </tr>
  <tr>
    <td>Medium</td>
    <td><code>3.9</code></td>
  </tr>
  <tr>
    <td>None</td>
    <td><code>1.95</code></td>
  </tr>
  <tr>
    <td>Low</td>
    <td><code>0.0</code></td>
  </tr>
  <tr>
    <td>Lowest</td>
    <td><code>-1.8</code></td>
  </tr>
  <tr>
    <td rowspan="3">Scheduled</td>
    <td>Today or earlier</td>
    <td><code>5.0</code></td>
  </tr>
  <tr>
    <td>Tomorrow or later</td>
    <td><code>0.0</code></td>
  </tr>
  <tr>
    <td>None</td>
    <td><code>0.0</code></td>
  </tr>
  <tr>
    <td rowspan="3">Start</td>
    <td>Today or earlier</td>
    <td><code>0.0</code></td>
  </tr>
  <tr>
    <td>Tomorrow or later</td>
    <td><code>-3.0</code></td>
  </tr>
  <tr>
    <td>None</td>
    <td><code>0.0</code></td>
  </tr>
</tbody>
</table>


<!-- placeholder to force blank line after included text -->
