<!-- placeholder to force blank line before included text -->

| Status Symbol | Next Status Symbol | Status Name<br>`status.name includes...`<br>`sort by status.name`<br>`group by status.name` | Status Type<br>`status.type is...`<br>`sort by status.type`<br>`group by status.type` | Needs Custom Styling |
| ----- | ----- | ----- | ----- | ----- |
| `space` | `x` | Unchecked | `TODO` | No |
| `x` | `space` | Checked | `DONE` | No |
| `>` | `x` | Rescheduled | `TODO` | Yes |
| `<` | `x` | Scheduled | `TODO` | Yes |
| `!` | `x` | Important | `TODO` | Yes |
| `-` | `space` | Cancelled | `CANCELLED` | Yes |
| `/` | `x` | In Progress | `IN_PROGRESS` | Yes |
| `?` | `x` | Question | `TODO` | Yes |
| `*` | `x` | Star | `TODO` | Yes |
| `n` | `x` | Note | `TODO` | Yes |
| `l` | `x` | Location | `TODO` | Yes |
| `i` | `x` | Information | `TODO` | Yes |
| `I` | `x` | Idea | `TODO` | Yes |
| `S` | `x` | Amount | `TODO` | Yes |
| `p` | `x` | Pro | `TODO` | Yes |
| `c` | `x` | Con | `TODO` | Yes |
| `b` | `x` | Bookmark | `TODO` | Yes |
| `"` | `x` | Quote | `TODO` | Yes |
| `0` | `0` | Speech bubble 0 | `NON_TASK` | Yes |
| `1` | `1` | Speech bubble 1 | `NON_TASK` | Yes |
| `2` | `2` | Speech bubble 2 | `NON_TASK` | Yes |
| `3` | `3` | Speech bubble 3 | `NON_TASK` | Yes |
| `4` | `4` | Speech bubble 4 | `NON_TASK` | Yes |
| `5` | `5` | Speech bubble 5 | `NON_TASK` | Yes |
| `6` | `6` | Speech bubble 6 | `NON_TASK` | Yes |
| `7` | `7` | Speech bubble 7 | `NON_TASK` | Yes |
| `8` | `8` | Speech bubble 8 | `NON_TASK` | Yes |
| `9` | `9` | Speech bubble 9 | `NON_TASK` | Yes |


<!-- placeholder to force blank line after included text -->
