<!-- placeholder to force blank line before included text -->

| Status Symbol | Next Status Symbol | Status Name<br>`status.name includes...`<br>`sort by status.name`<br>`group by status.name` | Status Type<br>`status.type is...`<br>`sort by status.type`<br>`group by status.type` | Needs Custom Styling |
| ----- | ----- | ----- | ----- | ----- |
| `space` | `x` | Unchecked | `TODO` | No |
| `x` | `space` | Checked | `DONE` | No |
| `>` | `x` | Rescheduled | `TODO` | Yes |
| `<` | `x` | Scheduled | `TODO` | Yes |
| `!` | `x` | Important | `TODO` | Yes |
| `-` | `space` | Cancelled | `CANCELLED` | Yes |
| `/` | `x` | In Progress | `IN_PROGRESS` | Yes |
| `?` | `x` | Question | `TODO` | Yes |
| `*` | `x` | Star | `TODO` | Yes |
| `n` | `x` | Note | `TODO` | Yes |
| `l` | `x` | Location | `TODO` | Yes |
| `i` | `x` | Information | `TODO` | Yes |
| `I` | `x` | Idea | `TODO` | Yes |
| `S` | `x` | Amount | `TODO` | Yes |
| `p` | `x` | Pro | `TODO` | Yes |
| `c` | `x` | Con | `TODO` | Yes |
| `b` | `x` | Bookmark | `TODO` | Yes |
| `f` | `x` | Fire | `TODO` | Yes |
| `k` | `x` | Key | `TODO` | Yes |
| `w` | `x` | Win | `TODO` | Yes |
| `u` | `x` | Up | `TODO` | Yes |
| `d` | `x` | Down | `TODO` | Yes |


<!-- placeholder to force blank line after included text -->
