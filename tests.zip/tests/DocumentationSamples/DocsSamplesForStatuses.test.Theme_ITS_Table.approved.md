<!-- placeholder to force blank line before included text -->

| Status Symbol | Next Status Symbol | Status Name<br>`status.name includes...`<br>`sort by status.name`<br>`group by status.name` | Status Type<br>`status.type is...`<br>`sort by status.type`<br>`group by status.type` | Needs Custom Styling |
| ----- | ----- | ----- | ----- | ----- |
| `space` | `x` | Unchecked | `TODO` | No |
| `x` | `space` | Regular | `DONE` | No |
| `X` | `space` | Checked | `DONE` | Yes |
| `-` | `space` | Dropped | `CANCELLED` | Yes |
| `>` | `x` | Forward | `TODO` | Yes |
| `D` | `x` | Date | `TODO` | Yes |
| `?` | `x` | Question | `TODO` | Yes |
| `/` | `x` | Half Done | `IN_PROGRESS` | Yes |
| `+` | `x` | Add | `TODO` | Yes |
| `R` | `x` | Research | `TODO` | Yes |
| `!` | `x` | Important | `TODO` | Yes |
| `i` | `x` | Idea | `TODO` | Yes |
| `B` | `x` | Brainstorm | `TODO` | Yes |
| `P` | `x` | Pro | `TODO` | Yes |
| `C` | `x` | Con | `TODO` | Yes |
| `Q` | `x` | Quote | `TODO` | Yes |
| `N` | `x` | Note | `TODO` | Yes |
| `b` | `x` | Bookmark | `TODO` | Yes |
| `I` | `x` | Information | `TODO` | Yes |
| `p` | `x` | Paraphrase | `TODO` | Yes |
| `L` | `x` | Location | `TODO` | Yes |
| `E` | `x` | Example | `TODO` | Yes |
| `A` | `x` | Answer | `TODO` | Yes |
| `r` | `x` | Reward | `TODO` | Yes |
| `c` | `x` | Choice | `TODO` | Yes |
| `d` | `x` | Doing | `IN_PROGRESS` | Yes |
| `T` | `x` | Time | `TODO` | Yes |
| `@` | `x` | Character / Person | `TODO` | Yes |
| `t` | `x` | Talk | `TODO` | Yes |
| `O` | `x` | Outline / Plot | `TODO` | Yes |
| `~` | `x` | Conflict | `TODO` | Yes |
| `W` | `x` | World | `TODO` | Yes |
| `f` | `x` | Clue / Find | `TODO` | Yes |
| `F` | `x` | Foreshadow | `TODO` | Yes |
| `H` | `x` | Favorite / Health | `TODO` | Yes |
| `&` | `x` | Symbolism | `TODO` | Yes |
| `s` | `x` | Secret | `TODO` | Yes |


<!-- placeholder to force blank line after included text -->
