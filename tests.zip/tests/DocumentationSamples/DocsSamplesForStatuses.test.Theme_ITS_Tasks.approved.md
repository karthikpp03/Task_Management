<!-- placeholder to force blank line before included text -->

- [ ] #task `space` Unchecked
- [x] #task `x` Regular
- [X] #task `X` Checked
- [-] #task `-` Dropped
- [>] #task `>` Forward
- [D] #task `D` Date
- [?] #task `?` Question
- [/] #task `/` Half Done
- [+] #task `+` Add
- [R] #task `R` Research
- [!] #task `!` Important
- [i] #task `i` Idea
- [B] #task `B` Brainstorm
- [P] #task `P` Pro
- [C] #task `C` Con
- [Q] #task `Q` Quote
- [N] #task `N` Note
- [b] #task `b` Bookmark
- [I] #task `I` Information
- [p] #task `p` Paraphrase
- [L] #task `L` Location
- [E] #task `E` Example
- [A] #task `A` Answer
- [r] #task `r` Reward
- [c] #task `c` Choice
- [d] #task `d` Doing
- [T] #task `T` Time
- [@] #task `@` Character / Person
- [t] #task `t` Talk
- [O] #task `O` Outline / Plot
- [~] #task `~` Conflict
- [W] #task `W` World
- [f] #task `f` Clue / Find
- [F] #task `F` Foreshadow
- [H] #task `H` Favorite / Health
- [&] #task `&` Symbolism
- [s] #task `s` Secret


<!-- placeholder to force blank line after included text -->
