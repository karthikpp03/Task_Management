<!-- placeholder to force blank line before included text -->

| Status Symbol | Next Status Symbol | Status Name<br>`status.name includes...`<br>`sort by status.name`<br>`group by status.name` | Status Type<br>`status.type is...`<br>`sort by status.type`<br>`group by status.type` | Needs Custom Styling |
| ----- | ----- | ----- | ----- | ----- |
| `space` | `x` | Unchecked | `TODO` | No |
| `x` | `space` | Checked | `DONE` | No |
| `-` | `space` | Cancelled | `CANCELLED` | Yes |
| `/` | `x` | In Progress | `IN_PROGRESS` | Yes |
| `>` | `x` | Deferred | `TODO` | Yes |
| `!` | `x` | Important | `TODO` | Yes |
| `?` | `x` | Question | `TODO` | Yes |
| `r` | `x` | Review | `TODO` | Yes |


<!-- placeholder to force blank line after included text -->
