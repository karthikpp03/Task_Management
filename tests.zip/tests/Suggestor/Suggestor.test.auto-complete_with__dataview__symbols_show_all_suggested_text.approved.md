| suggestion | expansion |
| ----- | ----- |
| ⏎ | &lt;new line> |
| due:: due date | due::  |
| start:: start date | start::  |
| scheduled:: scheduled date | scheduled::  |
| priority:: high high priority | priority:: high  |
| priority:: medium medium priority | priority:: medium  |
| priority:: low low priority | priority:: low  |
| priority:: highest highest priority | priority:: highest  |
| priority:: lowest lowest priority | priority:: lowest  |
| repeat:: recurring (repeat) | repeat::  |
| created:: created today (2022-07-11) | created:: 2022-07-11  |
| every | repeat:: every  |
| every day | repeat:: every day  |
| every week | repeat:: every week  |
| every month | repeat:: every month  |
| every month on the | repeat:: every month on the  |
| every year | repeat:: every year  |
| every week on Sunday | repeat:: every week on Sunday  |
| every week on Monday | repeat:: every week on Monday  |
| every week on Tuesday | repeat:: every week on Tuesday  |
| every week on Wednesday | repeat:: every week on Wednesday  |
| every week on Thursday | repeat:: every week on Thursday  |
| every week on Friday | repeat:: every week on Friday  |
| every week on Saturday | repeat:: every week on Saturday  |
| today (2022-07-11) | due:: 2022-07-11  |
| tomorrow (2022-07-12) | due:: 2022-07-12  |
| Sunday (2022-07-17) | due:: 2022-07-17  |
| Monday (2022-07-18) | due:: 2022-07-18  |
| Tuesday (2022-07-12) | due:: 2022-07-12  |
| Wednesday (2022-07-13) | due:: 2022-07-13  |
| Thursday (2022-07-14) | due:: 2022-07-14  |
| Friday (2022-07-15) | due:: 2022-07-15  |
| Saturday (2022-07-16) | due:: 2022-07-16  |
| next week (2022-07-18) | due:: 2022-07-18  |
| next month (2022-08-11) | due:: 2022-08-11  |
| next year (2023-07-11) | due:: 2023-07-11  |
| today (2022-07-11) | scheduled:: 2022-07-11  |
| tomorrow (2022-07-12) | scheduled:: 2022-07-12  |
| Sunday (2022-07-17) | scheduled:: 2022-07-17  |
| Monday (2022-07-18) | scheduled:: 2022-07-18  |
| Tuesday (2022-07-12) | scheduled:: 2022-07-12  |
| Wednesday (2022-07-13) | scheduled:: 2022-07-13  |
| Thursday (2022-07-14) | scheduled:: 2022-07-14  |
| Friday (2022-07-15) | scheduled:: 2022-07-15  |
| Saturday (2022-07-16) | scheduled:: 2022-07-16  |
| next week (2022-07-18) | scheduled:: 2022-07-18  |
| next month (2022-08-11) | scheduled:: 2022-08-11  |
| next year (2023-07-11) | scheduled:: 2023-07-11  |
| today (2022-07-11) | start:: 2022-07-11  |
| tomorrow (2022-07-12) | start:: 2022-07-12  |
| Sunday (2022-07-17) | start:: 2022-07-17  |
| Monday (2022-07-18) | start:: 2022-07-18  |
| Tuesday (2022-07-12) | start:: 2022-07-12  |
| Wednesday (2022-07-13) | start:: 2022-07-13  |
| Thursday (2022-07-14) | start:: 2022-07-14  |
| Friday (2022-07-15) | start:: 2022-07-15  |
| Saturday (2022-07-16) | start:: 2022-07-16  |
| next week (2022-07-18) | start:: 2022-07-18  |
| next month (2022-08-11) | start:: 2022-08-11  |
| next year (2023-07-11) | start:: 2023-07-11  |
