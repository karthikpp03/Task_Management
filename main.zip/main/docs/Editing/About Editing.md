---
publish: true
---

# About Editing

<span class="related-pages">#index-pages</span>

Tasks has a growing number of ways to conveniently add data to your task lines.

## General editing techniques

- [[Auto-Suggest]]
  - Intelligent auto-suggest facility does a lot of your typing of task data for you.
- [[Create or edit Task]]
  - Helpful dialog/modal for easy adding and editing of task data.

## Editing specific task properties

- [[Toggling and Editing Statuses]]
  - All the ways to edit task statuses.
- [[Postponing]]
  - Easy deferring or snoozing of due, scheduled and start dates.
