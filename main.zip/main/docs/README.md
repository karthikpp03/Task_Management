---
publish: false
---

# Documentation for Obsidian Tasks

## Extensive guides for documentors

Please visit our new [**About the Documentation**](https://publish.obsidian.md/tasks-contributing/Documentation/About+Documentation) site for lots of useful information about contributing to Tasks.

Many thanks!
