---
publish: true
---

# About Support and Help

<span class="related-pages">#index-pages</span>

## Pages in this section

- [[Known Limitations]]
- [[Breaking Changes]]
  - Tasks releases with version numbers ending `.0.0` indicate that an update to user vaults may be required.
- [[Report a Bug]]
