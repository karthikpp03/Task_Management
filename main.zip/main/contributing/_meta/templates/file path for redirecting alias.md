<% tp.file.path(true).replace(/\.md$/, "") %>
