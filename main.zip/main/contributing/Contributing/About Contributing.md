# Contributing to the Tasks plugin

<span class="related-pages">#pull-requests</span>

This page will grow to provide more background information for those thinking of submitting a [pull request](https://github.com/obsidian-tasks-group/obsidian-tasks/pulls) to the [Tasks Plugin](https://github.com/obsidian-tasks-group/obsidian-tasks).

- [[Updating code]]: recommendations for creating a pull request.
- [[Reviewing Pull Requests]]: reminders for anyone reviewing pull requests
