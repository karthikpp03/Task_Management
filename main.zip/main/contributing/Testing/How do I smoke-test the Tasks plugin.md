# How do I smoke-test the Tasks plugin?

<span class="related-pages">#testing/manual-testing</span>

Follow the steps in [resources/sample_vaults/Tasks-Demo/Manual Testing/Smoke Testing the Tasks Plugin.md](https://github.com/obsidian-tasks-group/obsidian-tasks/blob/main/resources/sample_vaults/Tasks-Demo/Manual%20Testing/Smoke%20Testing%20the%20Tasks%20Plugin.md).
