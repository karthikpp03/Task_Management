---
publish: true
---

# Jest Test Framework

<span class="related-pages">#testing/automated-testing</span>

The tests use the [ts-jest](https://www.npmjs.com/package/ts-jest) wrapper around the
[jest](https://jestjs.io) test framework.

The [Expect](https://jestjs.io/docs/expect) page is a good reference for the many jest testing features.
