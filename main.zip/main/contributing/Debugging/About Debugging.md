# Debugging

## Future Plans

This section is intended to document how to place debugger breakpoints in the Tasks code, so that the behaviour can be inspected at run-time.

## Current Content

- [[How do I enable hidden debugging and visualisation facilities]]
