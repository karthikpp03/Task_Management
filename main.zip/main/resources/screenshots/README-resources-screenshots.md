# resources/screenshots

New images should be put in `docs/images/` please.

For details, see <https://github.com/obsidian-tasks-group/obsidian-tasks/issues/1287>.
