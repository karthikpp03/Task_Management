# ACME

## Steps to world domination

- [ ] #task Take out the trash 🔁 every week on Monday 📅 2021-11-22
- [x] #task Take out the trash 🔁 every week on Monday 📅 2021-11-15 ✅ 2021-11-15
- [ ] #task **?** 📅 2021-11-22
- [ ] #task ==Profit== 📅 2021-11-22
- [ ] #task Cook dinner ⏫ ⏳ 2021-11-23
- [ ] #task Bake a cake 🔼 🛫 2021-11-25
- [ ] #task Feed the baby 🔽 📅 2021-11-21

## Model test

- [ ] This checklist item is not a task as it doesn't include the global filter
