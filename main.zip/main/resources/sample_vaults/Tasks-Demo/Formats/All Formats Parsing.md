# All Formats Parsing

## Tasks Format

- [/] #task This was Tasks format ⏫ 🔁 every day 🛫 2023-04-05 ⏳ 2023-04-06 📅 2023-04-07

## Dataview format

- [/] #task This was dataview [priority:: high] [repeat:: every day] [start:: 2023-04-05] [scheduled:: 2023-04-06] [due:: 2023-04-07]
